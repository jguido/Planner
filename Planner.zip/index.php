<script type="text/javascript">window.location.href="www.aides-asso.com"</script>
